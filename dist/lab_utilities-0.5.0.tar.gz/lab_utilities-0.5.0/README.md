# lab utilities
`pip install -e .`

`set-lab-email`
